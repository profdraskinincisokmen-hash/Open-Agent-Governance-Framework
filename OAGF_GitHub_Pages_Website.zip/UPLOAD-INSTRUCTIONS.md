# OAGF GitHub Pages Website

Upload the following files to the root of your GitHub repository:

- `index.html`
- `styles.css`
- `script.js`
- `logo.png`
- `architecture.png`

Keep your existing white paper PDF in the repository root with the exact name:

`Open Agent Governance Framework.pdf`

GitHub Pages will automatically use `index.html` as the website homepage.
